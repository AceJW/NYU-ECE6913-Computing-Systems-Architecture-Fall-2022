import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CSALabResultReader{
	public static void main(String[] args) {
		String[] myAnswer = new String[]{"dmemresult.txt","RFresult.txt","stateresult.txt"};
		String[] graderAnswer = new String[] {"dmemresult_grading.txt","RFresult_grading.txt","stateresult_grading.txt"};
		String myFileName = "";
		for(int x = 1;x<=22;x++) {
			
			int cIndex = 0;
			for(int n=0;n<3;n++) {
			File f = new File("./"+x+"/"+myAnswer[n]);
			File g = new File("./"+x+"/"+graderAnswer[n]);
			String inString = null;
			/* create a loop to read the file line-by-line */
			FileReader fReader = null;
			FileReader gReader = null;
		
				try {
					fReader = new FileReader(f);
					gReader = new FileReader(g);
					BufferedReader fin = new BufferedReader(fReader);
					BufferedReader gin = new BufferedReader(gReader);
					String fInLine = fin.readLine();
					String gInLine = gin.readLine();
					int lineIndex = 1;
					while(gInLine != null) {
						if(gInLine.contains("X")) {
							fInLine = fin.readLine();
							gInLine = gin.readLine();
							lineIndex++;
							continue;
						}else if(!(gInLine.contains("X")) && !fInLine.equals(gInLine)) {
							
							System.out.println("Error occur !!! Line: "+lineIndex);
							System.out.println("My "+" "+fInLine+" ("+f+")");
							System.out.println("Gr "+" "+gInLine+" ("+g+")");	
							fInLine = fin.readLine();
							gInLine = gin.readLine();
							lineIndex++;
							cIndex++;
							continue;
						}
						fInLine = fin.readLine();
						gInLine = gin.readLine();
						lineIndex++;
					}
				} catch(FileNotFoundException e) {
					 System.out.println("An error found(FileNotFoundException): "+e.getMessage());
					 
				} catch (IOException e) {
					System.out.println("An error found(IOException): "+e.getMessage());
				}
			}
			if( cIndex == 0 ) {
				if(x<10) {
					System.out.println("File 0"+x+" Verfied, no error found!");
				}else {
					System.out.println("File "+x+" Verfied, no error found!");
				}
				
			}
		}
	}
}